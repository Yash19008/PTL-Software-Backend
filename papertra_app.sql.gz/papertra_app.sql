-- Adminer 4.8.1 MySQL 5.5.5-10.4.24-MariaDB dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `audittrail`;
CREATE TABLE `audittrail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp(),
  `module` varchar(255) DEFAULT NULL,
  `user` varchar(255) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `ipaddress` varchar(255) DEFAULT NULL,
  `oldvalue` longtext DEFAULT NULL,
  `newvalue` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `challan_list`;
CREATE TABLE `challan_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(500) DEFAULT NULL,
  `mobile` varchar(500) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `challan_no` varchar(100) DEFAULT NULL,
  `quality` varchar(100) DEFAULT NULL,
  `size_inch_length` double(5,2) DEFAULT NULL,
  `size_inch_width` double(5,2) DEFAULT NULL,
  `gsm` int(11) DEFAULT NULL,
  `bdls` int(11) DEFAULT NULL,
  `pkt_grs` double(5,2) DEFAULT NULL,
  `sheets` int(11) DEFAULT NULL,
  `weight` double(10,2) DEFAULT NULL,
  `delivery_at` varchar(500) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `updated_on` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `challan_list_ptl`;
CREATE TABLE `challan_list_ptl` (
  `Id` varchar(100) NOT NULL,
  `Costomer_name` varchar(100) NOT NULL,
  `mobile_no` varchar(12) NOT NULL,
  `Date` varchar(100) NOT NULL,
  `Challan_no` varchar(100) NOT NULL,
  `Quality` varchar(100) NOT NULL,
  `Size_inch_lenght` float NOT NULL,
  `Size_inch_width` float NOT NULL,
  `GSM` varchar(100) NOT NULL,
  `Bdsl` varchar(100) NOT NULL,
  `Pkt_grs` float NOT NULL,
  `Sheets` varchar(100) NOT NULL,
  `Weight` varchar(500) NOT NULL,
  `Delivery_at` varchar(100) NOT NULL,
  `Status` varchar(100) NOT NULL,
  `Updated_on` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `cheque_collection`;
CREATE TABLE `cheque_collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL DEFAULT 0,
  `company_name` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `amount` float(10,2) NOT NULL DEFAULT 0.00,
  `remark` varchar(255) DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `ci_sessions`;
CREATE TABLE `ci_sessions` (
  `s_id` int(11) NOT NULL AUTO_INCREMENT,
  `id` varchar(100) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT 0,
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `s_id` (`s_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `countries`;
CREATE TABLE `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sortname` varchar(3) NOT NULL,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `customer_master`;
CREATE TABLE `customer_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Company_code` decimal(18,0) NOT NULL,
  `company_name` varchar(500) DEFAULT NULL,
  `client_name` varchar(500) DEFAULT NULL,
  `email` varchar(500) DEFAULT NULL,
  `mobile` varchar(30) DEFAULT NULL,
  `password` varchar(500) DEFAULT NULL,
  `otp` varchar(30) DEFAULT NULL COMMENT 'otp send here check convert into 1',
  `Access_stk` varchar(1) DEFAULT NULL,
  `active` enum('0','1') NOT NULL DEFAULT '0' COMMENT '1 is active and 0 is inactive',
  `stock_active` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0 is active and 1 is inactive',
  `oneSignalUserId` varchar(255) DEFAULT '',
  `oneSignalTokenId` varchar(255) DEFAULT NULL,
  `updated_on` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `customer_master_ptl`;
CREATE TABLE `customer_master_ptl` (
  `id` varchar(100) NOT NULL,
  `Company_code` varchar(100) NOT NULL,
  `Company_name` varchar(500) NOT NULL,
  `client_name` varchar(500) NOT NULL,
  `email` varchar(500) NOT NULL,
  `Mobile` varchar(10) NOT NULL,
  `Access_stock` varchar(500) NOT NULL,
  `update_on` varchar(500) NOT NULL,
  `Password` varchar(500) DEFAULT NULL,
  `OTP` varchar(500) DEFAULT NULL,
  `active` varchar(500) DEFAULT NULL,
  `Stock_active` varchar(500) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `customer_master_temp`;
CREATE TABLE `customer_master_temp` (
  `id` int(11) NOT NULL DEFAULT 0,
  `Company_code` decimal(18,0) NOT NULL,
  `company_name` varchar(500) DEFAULT NULL,
  `client_name` varchar(500) DEFAULT NULL,
  `email` varchar(500) DEFAULT NULL,
  `mobile` varchar(30) DEFAULT NULL,
  `password` varchar(500) DEFAULT NULL,
  `otp` varchar(30) DEFAULT NULL COMMENT 'otp send here check convert into 1',
  `Access_stk` varchar(1) DEFAULT NULL,
  `active` enum('0','1') NOT NULL DEFAULT '0' COMMENT '1 is active and 0 is inactive',
  `stock_active` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0 is active and 1 is inactive',
  `updated_on` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `demo`;
CREATE TABLE `demo` (
  `id` int(100) NOT NULL,
  `customer name` varchar(500) NOT NULL,
  `mobile no` varchar(50) NOT NULL,
  `e-mail` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `labels`;
CREATE TABLE `labels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


SET NAMES utf8mb4;

DROP TABLE IF EXISTS `laravel_failed_jobs`;
CREATE TABLE `laravel_failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `laravel_migrations`;
CREATE TABLE `laravel_migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `notification_master`;
CREATE TABLE `notification_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notification_title` varchar(500) NOT NULL,
  `notification_details` varchar(1000) NOT NULL,
  `last_date` date NOT NULL,
  `active` int(11) NOT NULL COMMENT '1 is active and 0 inactive',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `options_master`;
CREATE TABLE `options_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `option` varchar(50) NOT NULL,
  `detail` varchar(100) NOT NULL,
  `value` text NOT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1' COMMENT '0 is active 1 is inactive',
  `updated_dt` date NOT NULL,
  `updated_by` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `order_master`;
CREATE TABLE `order_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `cust_id` int(11) NOT NULL,
  `quality` varchar(500) NOT NULL,
  `size_inch_length` double(5,2) NOT NULL,
  `size_inch_width` double(5,2) NOT NULL,
  `gsm` int(11) NOT NULL,
  `product_group` varchar(100) DEFAULT NULL,
  `qty` int(11) NOT NULL,
  `weight` double(10,2) NOT NULL,
  `delivery_at` varchar(500) NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'P',
  `sync_status` enum('0','1') NOT NULL DEFAULT '0',
  `challan_number` varchar(50) DEFAULT NULL,
  `last_searched_id` int(11) DEFAULT NULL,
  `updated_dt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `update_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP VIEW IF EXISTS `order_master_view`;
CREATE TABLE `order_master_view` (`id` int(11), `date` datetime, `cust_id` int(11), `company_name` varchar(500), `quality` varchar(500), `size_inch_length` double(5,2), `size_inch_width` double(5,2), `gsm` int(11), `qty` int(11), `weight` double(10,2), `delivery_at` varchar(500), `challan_number` varchar(50), `last_searched_id` int(11), `status` varchar(12));


DROP TABLE IF EXISTS `outstanding`;
CREATE TABLE `outstanding` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `date` date DEFAULT NULL,
  `customer_name` varchar(500) DEFAULT NULL,
  `person_name` varchar(500) DEFAULT NULL,
  `mobile` varchar(500) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `voucher_type` varchar(500) DEFAULT NULL COMMENT 'sales_bill/chq_receipt',
  `voucher_no` varchar(100) DEFAULT NULL,
  `credit_days` int(5) DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `over_dues` int(5) DEFAULT NULL,
  `total_amount` double(10,2) DEFAULT NULL,
  `part_paid` double(10,2) DEFAULT NULL,
  `balance` double(10,2) DEFAULT NULL,
  `update_on` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `outstanding_ptl`;
CREATE TABLE `outstanding_ptl` (
  `Id` varchar(400) NOT NULL,
  `Date` varchar(100) NOT NULL,
  `Customer_name` varchar(500) NOT NULL,
  `Person_name` varchar(500) NOT NULL,
  `Mobile` varchar(500) NOT NULL,
  `E-mail` varchar(100) NOT NULL,
  `Voucher_type` varchar(500) NOT NULL,
  `Voucher_no` varchar(100) NOT NULL,
  `Credit_days` varchar(5) NOT NULL,
  `Due_date` varchar(100) NOT NULL,
  `Over_dues` varchar(50) NOT NULL,
  `Total_amt` float NOT NULL,
  `Part_paid` float NOT NULL,
  `Balance` float NOT NULL,
  `Update_on` varchar(100) NOT NULL,
  FULLTEXT KEY `Customer_name` (`Customer_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP VIEW IF EXISTS `outstanding_view`;
CREATE TABLE `outstanding_view` (`id` int(6), `date` date, `customer_name` varchar(500), `mobile` varchar(500), `voucher_type` varchar(500), `total_amount` double(19,2), `part_paid` double(10,2), `balance` double(19,2));


DROP TABLE IF EXISTS `peptek_stock`;
CREATE TABLE `peptek_stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_group` varchar(100) DEFAULT NULL,
  `gsm` int(11) DEFAULT NULL,
  `size_inch_length` double(5,2) DEFAULT NULL,
  `size_inch_width` double(5,2) DEFAULT NULL,
  `size_cms_length` double(5,2) DEFAULT NULL,
  `size_cms_width` double(5,2) DEFAULT NULL,
  `pkt_grs_weight` double(5,2) DEFAULT NULL,
  `sheet` int(11) DEFAULT NULL,
  `bdls` int(11) DEFAULT NULL,
  `pkg_mode` int(11) DEFAULT NULL,
  `pkt_grs` int(11) DEFAULT NULL,
  `weight` double(10,2) DEFAULT NULL,
  `quality` varchar(100) DEFAULT NULL,
  `gwd` varchar(100) DEFAULT NULL,
  `loc` varchar(100) DEFAULT NULL,
  `updated_on` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `product_group`;
CREATE TABLE `product_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(50) NOT NULL,
  `updated_on` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `push_notification`;
CREATE TABLE `push_notification` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `send_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `hours` int(11) NOT NULL,
  `type` enum('hour','minute') NOT NULL DEFAULT 'minute',
  `utilisation` int(11) NOT NULL,
  `message` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `push_not_data`;
CREATE TABLE `push_not_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `push_not_id` int(11) NOT NULL,
  `client_id` int(11) DEFAULT NULL,
  `company_name` varchar(50) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `onesignal_id` varchar(255) DEFAULT NULL,
  `size_in_inch` varchar(255) DEFAULT NULL,
  `product_group` varchar(191) DEFAULT NULL,
  `gsm` varchar(191) DEFAULT NULL,
  `record` text DEFAULT NULL,
  `onesignal_ref_id` varchar(255) DEFAULT NULL,
  `timestamp` timestamp NULL DEFAULT current_timestamp(),
  `message` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `search_history_master`;
CREATE TABLE `search_history_master` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) DEFAULT NULL,
  `company_name` varchar(500) DEFAULT NULL,
  `client_name` varchar(500) DEFAULT NULL,
  `email` varchar(500) DEFAULT NULL,
  `mobile` varchar(500) DEFAULT NULL,
  `width` varchar(10) NOT NULL,
  `heigth` varchar(10) NOT NULL,
  `size_in_inch` varchar(50) DEFAULT NULL,
  `gsm` varchar(50) DEFAULT NULL,
  `product_group` varchar(100) DEFAULT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `states`;
CREATE TABLE `states` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `countryID` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `stock`;
CREATE TABLE `stock` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_group` varchar(100) DEFAULT NULL,
  `gsm` int(11) DEFAULT NULL,
  `size_inch_length` double(5,2) DEFAULT NULL,
  `size_inch_width` double(5,2) DEFAULT NULL,
  `size_cms_length` double(5,2) DEFAULT NULL,
  `size_cms_width` double(5,2) DEFAULT NULL,
  `pkt_grs_weight` double(5,2) DEFAULT NULL,
  `sheet` int(11) DEFAULT NULL,
  `bdls` int(11) DEFAULT NULL,
  `pkg_mode` int(11) DEFAULT NULL,
  `pkt_grs` int(11) DEFAULT NULL,
  `weight` double(10,2) DEFAULT NULL,
  `quality` varchar(100) DEFAULT NULL,
  `gwd` varchar(100) DEFAULT NULL,
  `loc` varchar(100) DEFAULT NULL,
  `updated_on` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `stock_columns`;
CREATE TABLE `stock_columns` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `quality` enum('Yes','No') NOT NULL DEFAULT 'Yes',
  `gsm` enum('Yes','No') NOT NULL DEFAULT 'Yes',
  `size_inch` enum('Yes','No') NOT NULL DEFAULT 'Yes',
  `total_ups` enum('Yes','No') NOT NULL DEFAULT 'Yes',
  `utilization` enum('Yes','No') NOT NULL DEFAULT 'Yes',
  `sheet_weight` enum('Yes','No') NOT NULL DEFAULT 'Yes',
  `bundle` enum('Yes','No') NOT NULL DEFAULT 'Yes',
  `total_sheet` enum('Yes','No') NOT NULL DEFAULT 'Yes',
  `last_updated_on` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `stock_ptl`;
CREATE TABLE `stock_ptl` (
  `ID` varchar(100) NOT NULL,
  `GSM` varchar(100) NOT NULL,
  `Size_inch_lenght` float NOT NULL,
  `Size_inch_width` float NOT NULL,
  `Size_cms_length` float NOT NULL,
  `Size_cms_width` float NOT NULL,
  `Pkt_grs_weight` float NOT NULL,
  `Sheets` varchar(100) NOT NULL,
  `Bdls` varchar(100) NOT NULL,
  `Pkg_mode` float NOT NULL,
  `Pkt_grs` float NOT NULL,
  `Weight` float NOT NULL,
  `Quality` varchar(500) NOT NULL,
  `Gwd` varchar(50) NOT NULL,
  `Loc` varchar(50) NOT NULL,
  `Updated_on` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `stock_vendors`;
CREATE TABLE `stock_vendors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_group` varchar(100) DEFAULT NULL,
  `gsm` int(11) DEFAULT NULL,
  `size_inch_length` double(5,2) DEFAULT NULL,
  `size_inch_width` double(5,2) DEFAULT NULL,
  `size_cms_length` double(5,2) DEFAULT NULL,
  `size_cms_width` double(5,2) DEFAULT NULL,
  `pkt_grs_weight` double(5,2) DEFAULT NULL,
  `sheet` int(11) DEFAULT NULL,
  `bdls` int(11) DEFAULT NULL,
  `pkg_mode` int(11) DEFAULT NULL,
  `pkt_grs` int(11) DEFAULT NULL,
  `weight` double(10,2) DEFAULT NULL,
  `quality` varchar(100) DEFAULT NULL,
  `gwd` varchar(100) DEFAULT NULL,
  `loc` varchar(100) DEFAULT NULL,
  `vendor_id` bigint(20) DEFAULT NULL,
  `temp_flag` tinyint(4) NOT NULL DEFAULT 0,
  `updated_on` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `usermaster`;
CREATE TABLE `usermaster` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `employee_name` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `photo` varchar(200) DEFAULT NULL,
  `userlevel` int(11) NOT NULL,
  `user_status` varchar(20) NOT NULL,
  `mobile_no` bigint(20) NOT NULL,
  `home_no` bigint(20) NOT NULL,
  `email_id` varchar(100) NOT NULL,
  `address` varchar(150) NOT NULL,
  `country` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `pincode` int(20) NOT NULL,
  `qualification` varchar(100) NOT NULL,
  `joining_date` date NOT NULL,
  `comment` varchar(200) NOT NULL,
  `updated_dt` date NOT NULL,
  `updated_by` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `vendor_upload_history`;
CREATE TABLE `vendor_upload_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `_logs`;
CREATE TABLE `_logs` (
  `auditID` int(20) NOT NULL AUTO_INCREMENT,
  `ipaddress` varchar(50) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `module` varchar(50) DEFAULT NULL,
  `task` varchar(50) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `logdate` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`auditID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `_menu`;
CREATE TABLE `_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_caption` varchar(100) NOT NULL,
  `menu_active` varchar(2000) NOT NULL,
  `level` int(11) NOT NULL,
  `class_name` varchar(200) NOT NULL,
  `link` varchar(100) NOT NULL,
  `parent` int(11) NOT NULL,
  `sort` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `_role_menu`;
CREATE TABLE `_role_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `link` varchar(100) NOT NULL,
  `updated_dt` date NOT NULL,
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `_userlevels`;
CREATE TABLE `_userlevels` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userlevelsname` varchar(100) NOT NULL,
  `operation_permission` varchar(100) NOT NULL,
  `active` enum('1','0') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `order_master_view`;
CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `order_master_view` AS select `om`.`id` AS `id`,`om`.`date` AS `date`,`om`.`cust_id` AS `cust_id`,`cm`.`company_name` AS `company_name`,`om`.`quality` AS `quality`,`om`.`size_inch_length` AS `size_inch_length`,`om`.`size_inch_width` AS `size_inch_width`,`om`.`gsm` AS `gsm`,`om`.`qty` AS `qty`,`om`.`weight` AS `weight`,`om`.`delivery_at` AS `delivery_at`,`om`.`challan_number` AS `challan_number`,`om`.`last_searched_id` AS `last_searched_id`,if(`om`.`status` = 'P','Pending',if(`om`.`status` = 'B','Booked',if(`om`.`status` = 'NS','Not In Stock','Cancel'))) AS `status` from (`order_master` `om` left join `customer_master` `cm` on(`om`.`cust_id` = `cm`.`id`));

DROP TABLE IF EXISTS `outstanding_view`;
CREATE ALGORITHM=UNDEFINED DEFINER=`bkrufiyvmc69`@`localhost` SQL SECURITY DEFINER VIEW `outstanding_view` AS select `papertra_app`.`outstanding`.`id` AS `id`,`papertra_app`.`outstanding`.`date` AS `date`,`papertra_app`.`outstanding`.`customer_name` AS `customer_name`,`papertra_app`.`outstanding`.`mobile` AS `mobile`,`papertra_app`.`outstanding`.`voucher_type` AS `voucher_type`,sum(`papertra_app`.`outstanding`.`total_amount`) AS `total_amount`,`papertra_app`.`outstanding`.`part_paid` AS `part_paid`,sum(`papertra_app`.`outstanding`.`balance`) AS `balance` from `outstanding` group by `papertra_app`.`outstanding`.`customer_name`;

-- 2022-06-05 05:44:50
